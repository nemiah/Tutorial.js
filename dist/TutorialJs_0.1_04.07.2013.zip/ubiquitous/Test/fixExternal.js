var Aspect = {
	registerOnRmePCR: function(){
	
	}
}

$j = $;