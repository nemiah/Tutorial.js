<?php
/**
 *  This file is part of phynx.

 *  phynx is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.

 *  phynx is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.

 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 *  2007 - 2013, Rainer Furtmeier - Rainer@Furtmeier.IT
 */

class mMerlinGUI extends anyC implements iGUIHTMLMP2 {

	public function getHTML($id, $page){
		#$this->addOrderV3("MerlinHasChildren");
		$this->addOrderV3("MerlinDirName");
		$this->loadMultiPageMode($id, $page, 0);

		$gui = new HTMLGUIX($this);

		$gui->name("Merlin");
		
		$gui->attributes(array("MerlinDirName"));

		$gui->parser("MerlinDirName", "mMerlinGUI::dirParser");

		$B = $gui->addSideButton("git pull", "./plugins/Merlin/git.png");
		$B->popup("", "git pull", "mMerlin", "-1", "gitPull");
		
		$B = $gui->addSideButton("Einstellungen", "system");
		$B->popup("", "Einstellungen", "mMerlin", "-1", "settingsPopup");
		
		$B = $gui->addSideButton("ChangeLog", "./plugins/ChangeLog/ChangeLog.png");
		$B->popup("", "ChangeLog", "mChangeLog", "-1", "ChangeLogPopup", "", "", "{width:800}");
		
		return $gui->getBrowserHTML($id);
	}
	
	public function settingsPopup(){
		$F = new HTMLForm("MerlinSettings", array("buildPrefix"));
		
		$F->setValue("buildPrefix", mUserdata::getUDValueS("buildPrefix", ""));
		
		$F->setSaveRMEPCR("Einstellungen speichern", "", "mMerlin", "-1", "saveSettings", OnEvent::closePopup("mMerlin"));
		
		echo $F;
	}
	
	public function saveSettings($buildPrefix){
		mUserdata::setUserdataS("buildPrefix", $buildPrefix);
	}
	
	public function gitPull(){
		$SC = new SystemCommand();
		$SC->setCommand("cd /var/www/phynx && git pull origin master 2>&1");
		$SC->execute();
		$out1 = $SC->getOutput();
		
		$SC = new SystemCommand();
		$SC->setCommand("cd /var/www/phynx && git submodule update 2>&1");
		$SC->execute();
		$out2 = $SC->getOutput();
		
		echo "<h2>phynx</h2><pre style=\"font-size:10px;overflow:auto;max-height:400px;\">";
		echo $out1;
		echo "\nSubmodule:\n";
		echo $out2;
		echo "</pre>";
		
		$SC = new SystemCommand();
		$SC->setCommand("cd /var/www/phynxExtensions && git pull origin master 2>&1");
		$SC->execute();
		$out = $SC->getOutput();
		
		echo "<h2>phynxExtensions</h2><pre style=\"font-size:10px;overflow:auto;max-height:400px;\">";
		echo $out;
		echo "</pre>";
	}

	public static function dirParser($w, $E){
		$B = new Button("jetzt veröffentlichen", "./plugins/Merlin/deployNow.png");
		$B->onclick("if(!confirm('Jetzt deployen?')) return; $('contentLeft').update('<p>Bitte warten...</p>'); ");
		$B->rmePCR("Merlin", $E->getID(), "deploy", "true", "$('contentLeft').update(transport.responseText);");
		$B->type("icon");
		$B->style("float:left;margin-right:5px;");

		$BC = "";
		if($E->A("MerlinHasChildren") == "1"){
			$BC = new Button("hat Kinder", "./plugins/Merlin/hasChildren.png");
			$BC->type("icon");
			$BC->style("float:right;margin-left:5px;");
		}

		$dir = str_replace("/home/nemiah/NetBeansProjects/deploy/","", $w);
		$dir = str_replace("/var/www/deploy/","/v/w/d/", $dir);
		if($dir[strlen($dir) - 1] == "/"){
			$dir[strlen($dir) - 1] = " ";
			$dir = trim($dir);
		}

		return $BC.$B.$dir;
	}
}
?>