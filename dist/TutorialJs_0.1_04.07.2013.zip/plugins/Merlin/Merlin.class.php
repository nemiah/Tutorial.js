<?php
/**
 *  This file is part of plugins.

 *  plugins is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 3 of the License, or
 *  (at your option) any later version.

 *  plugins is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.

 *  You should have received a copy of the GNU General Public License
 *  along with this program.  If not, see <http://www.gnu.org/licenses/>.
 * 
 *  2007 - 2013, Rainer Furtmeier - Rainer@Furtmeier.IT
 */
class Merlin extends PersistentObject {
	public function getSettings(){
		$myPlugins = explode(";:;", $this->A("MerlinPlugins"));
		$allPlugins = $myPlugins;
		$allApps = explode(";:;", $this->A("MerlinApps"));
		
		$selections = $this->A("MerlinSelections");
		$specifics = $this->A("MerlinSpecificFiles");

		$parents = explode(";:;", $this->A("MerlinsParents"));
		if(count($parents) > 0)
			foreach($parents AS $parentID){
				if($parentID == "") continue;
				$M = new Merlin($parentID);

				$ParentData = $M->getSettings();

				$allPlugins = array_merge($allPlugins, $ParentData["allPlugins"]);
				$allApps = array_merge($allApps, $ParentData["applications"]);

				$selections .= "\n".$ParentData["selections"];
				$specifics .= "\n".$ParentData["specifics"];
			}

		$allPlugins = array_unique($allPlugins);
		$allApps = array_unique($allApps);
		
		$selections = implode("\n", array_unique(explode("\n", $selections)));
		$specifics = implode("\n", array_unique(explode("\n", $specifics)));
		
		sort($allPlugins);
		return array("allPlugins" => $allPlugins, "myPlugins" => $myPlugins, "selections" => trim($selections), "specifics" => trim($specifics), "applications" => $allApps);
	}
	
	public function getEMailData(){
		
		
		$data = array("fromName" => "Furtmeier Hard- und Software", "fromAddress" => "Support@Furtmeier.IT", "recipients" => $this->A("MerlinLastRecipient"), "subject" => "Ihre aktuelle Version", "body" => "\n\n\nFreundliche Grüße\nRainer Furtmeier");
		#$data["subject"] = "";
		#$data["body"] = $body;
		
		return $data;
		
		#return array("fromName" => Session::currentUser()->A("name"), "fromAddress" => Session::currentUser()->A("UserEmail"), "recipients" => array(array("recipientName" => $Adresse->A("firma") != "" ? $Adresse->A("firma") : $Adresse->A("vorname")." ".$Adresse->A("nachname"), $Adresse->A("email"))), "subject" => $subject, "body" => $body);
	}
	
	public function sendEmail($subject, $body, $recipient, $path){
		$data = $this->getEMailData();
		
		$mimeMail2 = new PHPMailer();
		
		$mimeMail2->CharSet = "UTF-8";
		$mimeMail2->Subject = $subject;
		
		$mimeMail2->From = $data["fromAddress"];
		$mimeMail2->Sender = $data["fromAddress"];
		$mimeMail2->FromName = $data["fromName"];
		$mimeMail2->AddReplyTo($data["fromAddress"]);
		
		$mimeMail2->IsHTML();
		
		$mimeMail2->AddAddress($recipient);
		
		$mimeMail2->Body = "<html>
  <head>
    <meta http-equiv=\"content-type\" content=\"text/html; charset=UTF-8\">
    <title></title>
  </head>
  <body bgcolor=\"#FFFFFF\" text=\"#000000\">
  ".nl2br($body)."<br /><br />
	<table>
		<tbody>
  			<tr>
  				<td style=\"width:115px;\">
					<img style=\"margin-right:15px;\" alt=\"Das Logo von Furtmeier Hard- und Software\" title=\"Das Logo von Furtmeier Hard- und Software\" src=\"HSLogo.png\" height=\"100\" width=\"100\">
				</td>
				<td style=\"width:300px;font-family:sans-serif;color:grey;font-size:10px;vertical-align:top\">
					Furtmeier Hard- und Software<br />
					Dipl.-Inf. Univ. Rainer Furtmeier<br />
					Neuteile 8<br />
					86682 Genderkingen<br />
					<br />
					Rainer@Furtmeier.IT<br />
					http://www.Furtmeier.IT
				</td>
			</tr>
		</tbody>
	</table>
  </body>
</html>";
		
		$mimeMail2->AddAttachment($path);
		$mimeMail2->AddEmbeddedImage(__DIR__."/HSLogo.png", md5(uniqid(time())), "", "base64", "image/png");
		
		if(!$mimeMail2->Send())
	    	throw new Exception("E-Mail: Failed to send e-mail! (".$mimeMail2->ErrorInfo.")");
		
		$this->changeA("MerlinLastRecipient", $recipient);
		$this->saveMe();
		
		Red::messageD("E-Mail verschickt");
	}
}
?>