<?php echo "This is a database-file."; /*
host&%%%&user&%%%&password&%%%&datab&%%%&httpHost
varchar(30)&%%%&varchar(20)&%%%&varchar(20)&%%%&varchar(20)&%%%&varchar(40)                                                                                                                                                       
localhost                     &%%%&root                &%%%&                    &%%%&phynx               &%%%&*                                       %%&&&
*/ ?>
