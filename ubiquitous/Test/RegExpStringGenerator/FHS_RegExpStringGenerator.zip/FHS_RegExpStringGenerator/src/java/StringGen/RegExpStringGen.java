package StringGen;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.URLDecoder;
import java.text.ParseException;
import java.util.Iterator;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import nl.flotsam.xeger.Xeger;
import org.json.JSONObject;

/**
 *
 * @author Marcel Block <mb@suchlotsen.de>
 */
public class RegExpStringGen extends HttpServlet {

	/**
	 * Processes requests for both HTTP
	 * <code>GET</code> and
	 * <code>POST</code> methods.
	 *
	 * @param request servlet request
	 * @param response servlet response
	 * @throws ServletException if a servlet-specific error occurs
	 * @throws IOException if an I/O error occurs
	 */
	protected void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		response.setContentType("text/html;charset=UTF-8");
		String key = "";
		String value = "";
		String generatedString = "";
		
		try {
//			String jsonReceiveString = URLDecoder.decode(request.getParameter("regexp"), "UTF-8");
			String jsonReceiveString = request.getParameter("regexp");
			try {
				JSONObject jsonReceive = new JSONObject(jsonReceiveString);
				JSONObject jsonReturn = new JSONObject();
				Iterator iterator = jsonReceive.keys();
				while (iterator.hasNext()) {
					key = (String) iterator.next();
					value = (String) jsonReceive.get(key);
					value = value.replace(".", "\\.");
					try {
						generatedString = this.generateString(value);
					} catch (StackOverflowError e) {
						generatedString = "";
						if (this.isEmail(value))
							generatedString = this.generateEmail(value);
					}
					jsonReturn.put(key, generatedString);
				}
				out.println(request.getParameter("jsonp_callback") + "(" + jsonReturn.toString() + ")");
			} catch (ParseException ex) {
				Logger.getLogger(RegExpStringGen.class.getName()).log(Level.SEVERE, null, ex);
			} catch (Exception ex) {
				Logger.getLogger(RegExpStringGen.class.getName()).log(Level.SEVERE, null, ex);
			}
		} finally {
			out.close();
		}
	}
	
	/**
	 * Prüft ein Pattern darauf ob es sich um eine Email handelt.
	 * @param suspectedEmailPattern
	 * @return boolean
	 */
	protected boolean isEmail(String suspectedEmailPattern) {
		Pattern emailPattern = Pattern.compile(".*@.*");
		Matcher emailMatcher = emailPattern.matcher(suspectedEmailPattern);
		return emailMatcher.find();
	}
	
	protected String generateEmail(String emailPattern) {
		if (!this.isEmail(emailPattern))
			return "";
		
		String[] email = emailPattern.split("@");
		String value = "";
		if (email.length == 2) {
			for (int i = 0; i < email.length; i++) {
				if (i == 1)
					value += "@";
				try {
					value += this.generateString(email[i]);
				} catch (StackOverflowError e) {
					value += "";
				}
			}
		}
		return value;
	}

	protected String generateString(String regExp) {
		Xeger stringGenerator = new Xeger(regExp);
		return stringGenerator.generate();
	}

	// <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
	/**
	 * Handles the HTTP
	 * <code>GET</code> method.
	 *
	 * @param request servlet request
	 * @param response servlet response
	 * @throws ServletException if a servlet-specific error occurs
	 * @throws IOException if an I/O error occurs
	 */
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		processRequest(request, response);
	}

	/**
	 * Handles the HTTP
	 * <code>POST</code> method.
	 *
	 * @param request servlet request
	 * @param response servlet response
	 * @throws ServletException if a servlet-specific error occurs
	 * @throws IOException if an I/O error occurs
	 */
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		processRequest(request, response);
	}

	/**
	 * Returns a short description of the servlet.
	 *
	 * @return a String containing servlet description
	 */
	@Override
	public String getServletInfo() {
		return "Short description";
	}// </editor-fold>
}
